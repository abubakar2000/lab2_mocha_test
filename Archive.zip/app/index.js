
exports.add = function add(a, b) {
    return a + b
}

exports.sub = function sub(a, b) {
    return a - b
}

exports.mul = function mul(a, b) {
    return a * b
}

exports.div = function div(a, b) {
    return a / b
}

